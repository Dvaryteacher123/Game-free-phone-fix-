"use client";

import { useEffect, useState } from "react";
import {
  collection,
  onSnapshot,
  orderBy,
  query,
} from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function HomePage() {
  const [notifications, setNotifications] = useState([]);
  const [games, setGames] = useState([]);
  const [loadingGames, setLoadingGames] = useState(true);

  // Soma "notifications" moja kwa moja (real-time) kutoka Firestore
  useEffect(() => {
    const q = query(
      collection(db, "notifications"),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setNotifications(data);
      },
      (error) => {
        console.error("Error kusoma notifications:", error);
      }
    );

    return () => unsubscribe();
  }, []);

  // Soma "games" moja kwa moja (real-time) kutoka Firestore
  useEffect(() => {
    const q = query(collection(db, "games"), orderBy("createdAt", "desc"));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const data = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setGames(data);
        setLoadingGames(false);
      },
      (error) => {
        console.error("Error kusoma games:", error);
        setLoadingGames(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const latestNotification = notifications[0];

  return (
    <main className="min-h-screen bg-cream-bg">
      {/* ================= NOTIFICATIONS BANNER ================= */}
      {latestNotification && (
        <div className="w-full bg-cream-accent text-cream-dark text-sm sm:text-base font-medium">
          <div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-full bg-cream-dark animate-pulse shrink-0" />
            <p className="truncate">
              <span className="font-bold">Taarifa: </span>
              {latestNotification.message}
            </p>
          </div>
        </div>
      )}

      {/* ================= NAVBAR ================= */}
      <header className="w-full border-b border-cream-card/60 bg-cream-bg/80 backdrop-blur sticky top-0 z-20">
        <nav className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2">
            <span className="text-2xl">🎮</span>
            <span className="text-xl font-bold tracking-tight">
              Game<span className="text-cream-accent">Hub</span>
            </span>
          </a>

          <div className="hidden sm:flex items-center gap-6 text-sm font-medium text-cream-dark/80">
            <a href="/" className="hover:text-cream-dark transition-colors">
              Nyumbani
            </a>
            <a href="#games" className="hover:text-cream-dark transition-colors">
              Michezo
            </a>
          </div>

          <a
            href="/admin"
            className="rounded-full bg-cream-dark text-cream-bg text-xs sm:text-sm font-semibold px-4 py-2 hover:opacity-90 transition-opacity"
          >
            ADMIN
          </a>
        </nav>
      </header>

      {/* ================= HERO ================= */}
      <section className="max-w-6xl mx-auto px-4 pt-14 pb-8 text-center">
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight">
          Cheza Michezo Bora Zaidi
        </h1>
        <p className="mt-4 text-cream-dark/70 max-w-xl mx-auto">
          Chagua mchezo unaoupenda hapa chini na ubofye "Play Now" kuanza
          kucheza papo hapo.
        </p>
      </section>

      {/* ================= GAMES GRID ================= */}
      <section id="games" className="max-w-6xl mx-auto px-4 pb-20">
        <h2 className="text-xl font-bold mb-6">Michezo Yote</h2>

        {loadingGames && (
          <p className="text-cream-dark/60">Inapakia michezo...</p>
        )}

        {!loadingGames && games.length === 0 && (
          <p className="text-cream-dark/60">
            Hakuna mchezo bado. Nenda /admin uongeze mchezo mpya.
          </p>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game) => (
            <div
              key={game.id}
              className="rounded-xl2 bg-cream-card border border-cream-dark/5 shadow-sm hover:shadow-md transition-shadow p-6 flex flex-col justify-between"
            >
              <div>
                <div className="h-12 w-12 rounded-xl bg-cream-accent/60 flex items-center justify-center text-2xl mb-4">
                  🕹️
                </div>
                <h3 className="text-lg font-bold mb-2">{game.title}</h3>
              </div>

              <a
                href={game.link}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-4 inline-flex items-center justify-center rounded-full bg-cream-dark text-cream-bg font-semibold py-2.5 px-4 hover:opacity-90 transition-opacity"
              >
                Play Now ▶
              </a>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-cream-card/60 py-6 text-center text-xs text-cream-dark/60">
        © {new Date().getFullYear()} GameHub. Haki zote zimehifadhiwa.
      </footer>
    </main>
  );
}
