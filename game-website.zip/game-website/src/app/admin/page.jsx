"use client";

import { useState } from "react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";

export default function AdminPage() {
  // ---- Game form state ----
  const [gameTitle, setGameTitle] = useState("");
  const [gameLink, setGameLink] = useState("");
  const [gameStatus, setGameStatus] = useState(null); // {type: 'success'|'error', text}
  const [savingGame, setSavingGame] = useState(false);

  // ---- Notification form state ----
  const [message, setMessage] = useState("");
  const [notifStatus, setNotifStatus] = useState(null);
  const [savingNotif, setSavingNotif] = useState(false);

  async function handleAddGame(e) {
    e.preventDefault();
    if (!gameTitle.trim() || !gameLink.trim()) {
      setGameStatus({ type: "error", text: "Tafadhali jaza sehemu zote mbili." });
      return;
    }

    setSavingGame(true);
    setGameStatus(null);
    try {
      await addDoc(collection(db, "games"), {
        title: gameTitle.trim(),
        link: gameLink.trim(),
        createdAt: serverTimestamp(),
      });
      setGameTitle("");
      setGameLink("");
      setGameStatus({ type: "success", text: "Mchezo umeongezwa kikamilifu ✅" });
    } catch (error) {
      console.error(error);
      setGameStatus({ type: "error", text: "Imeshindikana kuhifadhi. Jaribu tena." });
    } finally {
      setSavingGame(false);
    }
  }

  async function handleSendNotification(e) {
    e.preventDefault();
    if (!message.trim()) {
      setNotifStatus({ type: "error", text: "Andika ujumbe kwanza." });
      return;
    }

    setSavingNotif(true);
    setNotifStatus(null);
    try {
      await addDoc(collection(db, "notifications"), {
        message: message.trim(),
        createdAt: serverTimestamp(),
      });
      setMessage("");
      setNotifStatus({ type: "success", text: "Taarifa imetumwa kikamilifu ✅" });
    } catch (error) {
      console.error(error);
      setNotifStatus({ type: "error", text: "Imeshindikana kutuma. Jaribu tena." });
    } finally {
      setSavingNotif(false);
    }
  }

  return (
    <main className="min-h-screen bg-cream-bg py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-extrabold">Admin Panel</h1>
            <p className="text-cream-dark/60 text-sm">
              Simamia michezo na taarifa za tovuti
            </p>
          </div>
          <a
            href="/"
            className="text-sm font-medium text-cream-dark/70 hover:text-cream-dark underline"
          >
            ← Rudi Nyumbani
          </a>
        </div>

        {/* ============ FOMU 1: ONGEZA GAME MPYA ============ */}
        <div className="rounded-xl2 bg-cream-card p-6 mb-8 shadow-sm">
          <h2 className="text-lg font-bold mb-4">🎮 Ongeza Game Mpya</h2>
          <form onSubmit={handleAddGame} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-1">
                Game Title
              </label>
              <input
                type="text"
                value={gameTitle}
                onChange={(e) => setGameTitle(e.target.value)}
                placeholder="mfano: Subway Surfers"
                className="w-full rounded-lg border border-cream-dark/10 bg-cream-bg px-4 py-2.5 outline-none focus:ring-2 focus:ring-cream-accent"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold mb-1">
                Game Link / URL
              </label>
              <input
                type="url"
                value={gameLink}
                onChange={(e) => setGameLink(e.target.value)}
                placeholder="https://..."
                className="w-full rounded-lg border border-cream-dark/10 bg-cream-bg px-4 py-2.5 outline-none focus:ring-2 focus:ring-cream-accent"
              />
            </div>

            <button
              type="submit"
              disabled={savingGame}
              className="w-full rounded-full bg-cream-dark text-cream-bg font-semibold py-3 hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {savingGame ? "Inahifadhi..." : "Hifadhi Game"}
            </button>

            {gameStatus && (
              <p
                className={`text-sm font-medium ${
                  gameStatus.type === "success"
                    ? "text-green-700"
                    : "text-red-600"
                }`}
              >
                {gameStatus.text}
              </p>
            )}
          </form>
        </div>

        {/* ============ FOMU 2: TUMA NOTISI ============ */}
        <div className="rounded-xl2 bg-cream-card p-6 shadow-sm">
          <h2 className="text-lg font-bold mb-4">📢 Tuma Notisi kwa Wachezaji</h2>
          <form onSubmit={handleSendNotification} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold mb-1">Ujumbe</label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Andika taarifa itakayoonekana juu ya tovuti..."
                rows={4}
                className="w-full rounded-lg border border-cream-dark/10 bg-cream-bg px-4 py-2.5 outline-none focus:ring-2 focus:ring-cream-accent resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={savingNotif}
              className="w-full rounded-full bg-cream-accent text-cream-dark font-semibold py-3 hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {savingNotif ? "Inatuma..." : "Tuma Taarifa"}
            </button>

            {notifStatus && (
              <p
                className={`text-sm font-medium ${
                  notifStatus.type === "success"
                    ? "text-green-700"
                    : "text-red-600"
                }`}
              >
                {notifStatus.text}
              </p>
            )}
          </form>
        </div>
      </div>
    </main>
  );
}
