import "./globals.css";

export const metadata = {
  title: "GameHub — Cheza Michezo Bora",
  description: "Tovuti ya kisasa ya michezo mbalimbali - cheza bure moja kwa moja.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="sw">
      <body className="bg-cream-bg min-h-screen text-cream-dark font-sans antialiased">
        {children}
      </body>
    </html>
  );
}
